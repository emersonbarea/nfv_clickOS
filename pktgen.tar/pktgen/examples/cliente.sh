
rmmod pktgen
insmod /usr/src/pktgen/pktgen.ko

echo rx_reset > /proc/net/pktgen/pgrx
echo rx_disable > /proc/net/pktgen/pgrx

echo rx eth0 > /proc/net/pktgen/pgrx
echo statistics time > /proc/net/pktgen/pgrx

cat /proc/net/pktgen/pgrx
