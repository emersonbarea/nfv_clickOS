#!/bin/sh

rmmod pktgen
insmod /usr/src/pktgen/pktgen.ko

#$1 type of statistics
#$2 interface
pgset () {
	local result
	echo $1 > $PGDEV
}
#Reception configuration
PGDEV=/proc/net/pktgen/pgrx
	echo  "Disabling receiver"
	pgset "rx_disable"
	echo  "Cleaning statistics"
	pgset "rx_reset"
	echo  "Adding rx $2"
	pgset "rx $2"
	echo  "Setting statistics $1"
	pgset "statistics $1"

cat /proc/net/pktgen/pgrx
echo
echo "cat /proc/net/pktgen/pgrx"
