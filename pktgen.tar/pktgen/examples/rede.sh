ifconfig eth0 20.0.0.1/24
route add -net 10.0.0.0/8 gw 20.0.0.254
