rmmod pktgen
insmod /usr/src/pktgen/pktgen.ko


echo rx_reset > /proc/net/pktgen/pgrx
echo rx_disable > /proc/net/pktgen/pgrx

./lab1

cat /proc/net/pktgen/eth0
